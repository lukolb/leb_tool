<?php
// config.php (updated by admin/settings.php)
return array (
  'db' => 
  array (
    'host' => 'database-5019248017.webspace-host.com',
    'port' => 3306,
    'name' => 'dbs15099476',
    'user' => 'dbu5117686',
    'pass' => 'sD7!NLzm@38BpJ',
    'charset' => 'utf8mb4',
  ),
  'app' => 
  array (
    'session_name' => 'legtool_sess',
    'password_pepper' => '5f3079015de906f5ce54d97c23a41d583c89526f8232a37f220ad79a6804a0f2',
    'base_path' => '/leb_pdf',
    'public_base_url' => 'https://schultool.com/leb_pdf',
    'default_school_year' => '2025/26',
    'brand' => 
    array (
      'primary' => '#22409A',
      'secondary' => '#F7931C',
      'logo_path' => 'uploads/branding/logo.png',
      'org_name' => 'German International School New York',
    ),
    'uploads_dir' => 'uploads',
  ),
  'mail' => 
  array (
    'from_email' => 'noreply@schultool.com',
    'from_name' => 'GISNY LEG Tool',
  ),
);
